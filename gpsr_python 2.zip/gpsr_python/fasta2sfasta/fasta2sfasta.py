#=================================================================
# program developed for computing amino acid composition of proteins
# Usage: fasta2sfasta –i seq.fa -o seq.sfa
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   outputfile = ''
   if len(argv[1:])==0:
       #print("\n Usage for displaying on screen: python pro2dpc -i seq.sfa -o seq.out")
       print("usage python fasta2sfasta –i seq.fa -o seq.sfa\n")
       print("-i\t Input file name (.fa) \n-o\t Output file name (.sfa) ")
       sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
   except getopt.GetoptError:
      print ('fasta2sfasta.py -i <inputfile> -o <outputfile>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('fasta2sfasta.py -i <inputfile> -o <outputfile>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
		 
  	
   string_to_add = "##"
   i = 0
   k = 0

   with open(inputfile,'r') as f:
    file_lines = [''.join([x.strip(), string_to_add, ]) for x in f.readlines()]
	
   orig_stdout = sys.stdout
   n = open(outputfile,'w')	
   sys.stdout = n	
 
   while i < len(file_lines):
    if '>' not in file_lines[i]:
     j = i
     file_lines[j] = file_lines[j].rstrip('##') 
    i += 1 
  
   while k < len(file_lines):
    if '>' in file_lines[k]:
     file_lines[k] = file_lines[k] + file_lines[k+1] 	
     print(file_lines[k])
    k += 1  	
	
if __name__ == "__main__":
   #main(sys.argv[1:])
   main(sys.argv[1:])	
	
	