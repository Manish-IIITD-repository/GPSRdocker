#=================================================================
# program developed for computing Dipeptide composition of of C-terminal residues of a protein
# Usage: pro2dpc_ct -i seq.sfa -o seq.out -n 5
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   outputfile = ''
   number = 1
   if len(argv[1:])==0:
       #print("\n Usage for displaying on screen: python pro2dpc -i seq.sfa -o seq.out")
       print("usage python pro2dpc_ct.py -i seq.sfa -o seq.out -n number\n")
       print("-i\t Inputfile \n-o\t Outputfile \n-n\t Number of residues to calculate dipeptide composition from C-terminal ")
       sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:n:",["ifile=","ofile=","number="])
   except getopt.GetoptError:
      print ('pro2dpc_ct.py -i <inputfile> -o <outputfile> -n <number>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('pro2dpc_ct.py -i <inputfile> -o <outputfile> -n <number>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-n", "--number"):
         number = int(sys.argv[6])	  
		 
   with open(inputfile,'r') as f:
    g = list(f)	
	
   orig_stdout = sys.stdout
   n = open(outputfile,'w')	
   sys.stdout = n

   print("Dipeptide composition of of N-terminal residues of a protein")
   print("AA , AC , AD , AE , AF , AG , AH , AI , AK , AL , AM , AN , AP , AQ , AR , AS , AT , AV , AW , AY , CA , CC , CD , CE , CF , CG , CH , CI , CK , CL , CM , CN , CP , CQ , CR , CS , CT , CV , CW , CY , DA , DC , DD , DE , DF , DG , DH , DI , DK , DL , DM , DN , DP , DQ , DR , DS , DT , DV , DW , DY , EA , EC , ED , EE , EF , EG , EH , EI , EK , EL , EM , EN , EP , EQ , ER , ES , ET , EV , EW , EY , FA , FC , FD , FE , FF , FG , FH , FI , FK , FL , FM , FN , FP , FQ , FR , FS , FT , FV , FW , FY , GA , GC , GD , GE , GF , GG , GH , GI , GK , GL , GM , GN , GP , GQ , GR , GS , GT , GV , GW , GY , HA , HC , HD , HE , HF , HG , HH , HI , HK , HL , HM , HN , HP , HQ , HR , HS , HT , HV , HW , HY , IA , IC , ID , IE , IF , IG , IH , II , IK , IL , IM , IN , IP , IQ , IR , IS , IT , IV , IW , IY , KA , KC , KD , KE , KF , KG , KH , KI , KK , KL , KM , KN , KP , KQ , KR , KS , KT , KV , KW , KY , LA , LC , LD , LE , LF , LG , LH , LI , LK , LL , LM , LN , LP , LQ , LR , LS , LT , LV , LW , LY , MA , MC , MD , ME , MF , MG , MH , MI , MK , ML , MM , MN , MP , MQ , MR , MS , MT , MV , MW , MY , NA , NC , ND , NE , NF , NG , NH , NI , NK , NL , NM , NN , NP , NQ , NR , NS , NT , NV , NW , NY , PA , PC , PD , PE , PF , PG , PH , PI , PK , PL , PM , PN , PP , PQ , PR , PS , PT , PV , PW , PY , QA , QC , QD , QE , QF , QG , QH , QI , QK , QL , QM , QN , QP , QQ , QR , QS , QT , QV , QW , QY , RA , RC , RD , RE , RF , RG , RH , RI , RK , RL , RM , RN , RP , RQ , RR , RS , RT , RV , RW , RY , SA , SC , SD , SE , SF , SG , SH , SI , SK , SL , SM , SN , SP , SQ , SR , SS , ST , SV , SW , SY , TA , TC , TD , TE , TF , TG , TH , TI , TK , TL , TM , TN , TP , TQ , TR , TS , TT , TV , TW , TY , VA , VC , VD , VE , VF , VG , VH , VI , VK , VL , VM , VN , VP , VQ , VR , VS , VT , VV , VW , VY , WA , WC , WD , WE , WF , WG , WH , WI , WK , WL , WM , WN , WP , WQ , WR , WS , WT , WV , WW , WY , YA , YC , YD , YE , YF , YG , YH , YI , YK , YL , YM , YN , YP , YQ , YR , YS , YT , YV , YW , YY")
   i = 0
   i1 = 0
#nt = 5
   count = 1
   count1 = 1
   k = 0
   n = 0 
   m = 0
   j = 0
   perc = 0
   r = 0
   s = 0
   aa=['AA','AC','AD','AE','AF','AG','AH','AI','AK','AL','AM','AN','AP','AQ','AR','AS','AT','AV','AW','AY','CA','CC','CD','CE','CF','CG','CH','CI','CK','CL','CM','CN','CP','CQ','CR','CS','CT','CV','CW','CY','DA','DC','DD','DE','DF','DG','DH','DI','DK','DL','DM','DN','DP','DQ','DR','DS','DT','DV','DW','DY','EA','EC','ED','EE','EF','EG','EH','EI','EK','EL','EM','EN','EP','EQ','ER','ES','ET','EV','EW','EY','FA','FC','FD','FE','FF','FG','FH','FI','FK','FL','FM','FN','FP','FQ','FR','FS','FT','FV','FW','FY','GA','GC','GD','GE','GF','GG','GH','GI','GK','GL','GM','GN','GP','GQ','GR','GS','GT','GV','GW','GY','HA','HC','HD','HE','HF','HG','HH','HI','HK','HL','HM','HN','HP','HQ','HR','HS','HT','HV','HW','HY','IA','IC','ID','IE','IF','IG','IH','II','IK','IL','IM','IN','IP','IQ','IR','IS','IT','IV','IW','IY','KA','KC','KD','KE','KF','KG','KH','KI','KK','KL','KM','KN','KP','KQ','KR','KS','KT','KV','KW','KY','LA','LC','LD','LE','LF','LG','LH','LI','LK','LL','LM','LN','LP','LQ','LR','LS','LT','LV','LW','LY','MA','MC','MD','ME','MF','MG','MH','MI','MK','ML','MM','MN','MP','MQ','MR','MS','MT','MV','MW','MY','NA','NC','ND','NE','NF','NG','NH','NI','NK','NL','NM','NN','NP','NQ','NR','NS','NT','NV','NW','NY','PA','PC','PD','PE','PF','PG','PH','PI','PK','PL','PM','PN','PP','PQ','PR','PS','PT','PV','PW','PY','QA','QC','QD','QE','QF','QG','QH','QI','QK','QL','QM','QN','QP','QQ','QR','QS','QT','QV','QW','QY','RA','RC','RD','RE','RF','RG','RH','RI','RK','RL','RM','RN','RP','RQ','RR','RS','RT','RV','RW','RY','SA','SC','SD','SE','SF','SG','SH','SI','SK','SL','SM','SN','SP','SQ','SR','SS','ST','SV','SW','SY','TA','TC','TD','TE','TF','TG','TH','TI','TK','TL','TM','TN','TP','TQ','TR','TS','TT','TV','TW','TY','VA','VC','VD','VE','VF','VG','VH','VI','VK','VL','VM','VN','VP','VQ','VR','VS','VT','VV','VW','VY','WA','WC','WD','WE','WF','WG','WH','WI','WK','WL','WM','WN','WP','WQ','WR','WS','WT','WV','WW','WY','YA','YC','YD','YE','YF','YG','YH','YI','YK','YL','YM','YN','YP','YQ','YR','YS','YT','YV','YW','YY']

   while i < len(g) :
    g[i] = g[i].replace("\n","")
    g[i] = g[i].split('##', 1)[-1]
    g[i] = list(reversed(g[i]))
    i = i + 1

   import numpy
   h = numpy.zeros(shape=(len(g),len(g[0])-1), dtype=object)
   bb = numpy.zeros(shape=(len(g),400), dtype=object)
 
   while k < len(g) :
    while j < len(g[0]) :
     if j+2 <= len(g[0]) :
      h[k][j] = g[k][j:j+2]
     j += 1
    j = 0 
    k += 1 
 
   while m < len(g) :
    while n < number - 1 :
     while r < number - 1 :
      if n != r :
       if h[m][n] == h[m][r] :
        count1 = count1 + 1
       else :
        count = count1 
      r += 1
     if(count1 > count) :
      perc = count1 * 100/(number - 1)
     else :
      perc = count * 100/(number - 1)
  #print(count1)
  #print(count)  
  #print(h[m][n]) 
  #print(perc)
     while s < 400 :
      if (h[m][n] == list(aa[s])) :
       bb[m][s] = perc
      s += 1	
     r = 0
     s = 0
     count = 1
     count1 = 1
     n += 1
    n = 0
    m += 1
 
   for r in bb:
    for c in r:
     print(c,end = ",")
    print()    

if __name__ == "__main__":
   #main(sys.argv[1:])
 main(sys.argv[1:])  