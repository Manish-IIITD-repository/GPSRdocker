#=================================================================
# program developed for computing Amino Acid composition of N-terminal (nt) residues of a protein
# Usage: pro2aac_nt.py -i seq.sfa -o seq.out -n nt_residues
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
#from collections import defaultdict

def main(argv):
  inputfile = ''
  outputfile = ''
  nfile = ''

  if len(argv[1:]) == 0:
        print ("\nUsage for displaying on screen: python pro2aac_nt.py -i sfasta_file -n nt_residues(number)")
        print ("Usage: python pro2aac_nt.py -i sfasta_file -o output_file -n nt_residues(number)")
        print ("-i\tGive S-FASTA input file name\n-o\tOutput file name\n-n\tGive the number of residue for N terminal composition")
        sys.exit()

  try:

    opts, args = getopt.getopt(argv,"hi:o:n:",["ifile=","ofile=", "number"])
  except getopt.GetoptError:

    print ('pro2aac_nt.py -i <inputfile> -o <outputfile> -n <number>')
    sys.exit(2)  
   

  for opt, arg in opts:
      if opt == '-h':
         print ('pro2aac_nt.py -i <inputfile> -o <outputfile> -n <number>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-n", "--number"):
          nfile = arg
		   

  with open(inputfile,'r') as f:
    g = list(f)

 
  orig_stdout = sys.stdout
  n = open(outputfile,'w')	
  sys.stdout = n
 
  aa = ['A','C','D','E','F','G','H','I','K','L','M','N','P','Q','R','S','T','V','W','Y']
  print("Amino Acid composition of N-terminal (nt) residues of a protein \n")
  print("A , C , D , E , F , G , H , I , K , L , M , N , P , Q , R , S , T , V , W , Y\n")
 
  i = 0


  while i < len(g) :
    g[i] = g[i].replace("\n","")
    g[i] = g[i].split('##', 1)[-1]
    i+=1
    

#  print(g)  

  ind=int(nfile)

  for k in g:
    sub_str=k[0:ind]
    new_list=[0]*len(aa)
    for let in sub_str:
      ind1=aa.index(let)
      new_list[ind1]=new_list[ind1]+1
    new_list = [x*100 / ind for x in new_list]
    
  for r in new_list:
    print(r,end = ",")
      
  

main(sys.argv[1:])


     
