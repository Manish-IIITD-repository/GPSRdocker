#=================================================================
# program developed to add columns of two files
# Usage: col_add -i se1.out -c se2.out  -o seq.out
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile1 = ''
   inputfile2 = ''
   outputfile = ''
   h = 0
   
   if len(argv[1:]) == 0:
#        print ('col_add.py -i <inputfile1> -c <inputfile2> -o <outputfile>')
        print ("\nIn this two different features (e.g. amino acid composition, and dipeptided) of a sequence are added to make a more informative hybrid features.\n")
        print ("Usage:python col_add.py -i <inputfile1> -c <inputfile2> -o <outputfile>\n")
        print ('-i\tInputFile(first column file for add)\n-c\tInputFile(second column file for add)\n-o\tOutput file\n')
        sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:c:o:",["ifile1=","ifile2=","ofile="])
   except getopt.GetoptError:
      print ('col_add.py -i <inputfile1> -c <inputfile2> -o <outputfile>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('col_add.py -i <inputfile> -o <outputfile>')
         sys.exit()
      elif opt in ("-i", "--ifile1"):
         inputfile1 = arg
      elif opt in ("-c", "--ifile2"):
         inputfile2 = arg	 
      elif opt in ("-o", "--ofile"):
         outputfile = arg
		 
   with open(inputfile1,'r') as f1:
    g1 = list(f1)	
	
   with open(inputfile2,'r') as f2:
    g2 = list(f2)
  
   i = 0
   j = 0
   while i < len(g1) :
    g1[i] = g1[i].replace("\n","")
    i += 1
    
   while j < len(g2) :
    g2[j] = g2[j].replace("\n","")
    j += 1 
    
	
   orig_stdout = sys.stdout
   n = open(outputfile,'w')	
   sys.stdout = n
   
   #g1[2] = g1[2].split(",")
   #g2[2] = g2[2].split(",")
 
   while h < len(g2) : 
    print ("{0}".format(g1[h]+g2[h]))
    h += 1
 
if __name__ == "__main__":
   #main(sys.argv[1:])
 main(sys.argv[1:])          