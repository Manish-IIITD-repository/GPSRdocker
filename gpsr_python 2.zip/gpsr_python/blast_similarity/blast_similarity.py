import sys, getopt
#import numpy as np

def main(argv):
   inputfile = ''
   outputfile = ''
   database = ''
   
   if len(argv[1:]) == 0:
#        print ('seq2motif.py -i <inputfile> -o <outputfile> -w <window> -x <extension>')
        print ("\nTo perform blast.\n")
        print ("Usage:python blast_similarity -i fasta -d nr -j 3 -e 1 –o blast.out\n")
        print ('-i\tInputFile (FASTA FORMAT)\n-d\tDatabase\n-j\tNo_of_iterations\n-e\tExpected value\n-o\toutputFile\n')
        sys.exit()

   try:
       # opts is a list of returning key-value pairs, args is the options left after striped
       # the short options 'hi:o:', if an option requires an input, it should be followed by a ":"
       # the long options 'ifile=' is an option that requires an input, followed by a "="
      opts, args = getopt.getopt(argv,"i:d:j:e:o:",["ifile=","dbase=","itr=","ex=","ofile="])
   except getopt.GetoptError:
      print ('Error')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('blast_similarity.py -i <inputfile> -d <database> -j <iteration> -e <e_value>  -o <outputfile>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-d", "--dbase"):
         database = sys.argv[4]
      elif opt in ("-j", "--itr"):
         iteration = sys.argv[6] 
      elif opt in ("-e", "--ex"):
         e_value = sys.argv[8]	 
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      
		 
   orig_stdout = sys.stdout
   n1 = open(outputfile,'w')     
   sys.stdout = n1		 
		 
   import io
   import os
   import shlex
   import subprocess
   i = 0
   x = 0
   cmd = '/usr/bin/python3 /home/akshara/test/fasta2sfasta.py -i {} -o {}'.format(inputfile, outputfile)
   os.system(cmd)
   
   filename, file_extension = os.path.splitext(inputfile)
   filename_o, file_extension_o = os.path.splitext(outputfile)
   os.rename(outputfile, filename_o + '.sfasta')
   inputfile1 = filename_o + ".sfasta"
   
   n3 = open('temp','w')
   with open(inputfile1,'r') as f1:
    g1 = list(f1)
       
   while i < len(g1) :
    g1[i] = g1[i].replace("\n","")
    g1[i] = g1[i].split('##', 1)[-1]
    i = i + 1 
    
   while x < len(g1) :
    n3.write(g1[x] + "\n")
    x += 1
    print("\n")
    
   n3.close() 
   
   temp = "temp"
   n1.truncate()
   n4 = open(outputfile,'w') 
   #test = "test.out"
   S = '/home/gpsr/software/blastpr/blastpgp -d /home/gpsr/data/blastdata/{} -i {} -j {} -e {} -o {}'.format(database, temp, iteration, e_value, outputfile)
   os.system(S)
   
   os.system('rm temp ')
   
     
   n4.close()
   #n1.close()
   
main(sys.argv[1:])   
   
   
   
   
    
    
   
   
    