#=================================================================
# program developed to  normalize pssm profile ( = 1/(1+e-x)
# Usage: pssm_n1.py -i pssm_col_file -o outputfile
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy as np
import pandas as pd

def main(argv):
   inputfile = ''
   outputfile = ''
   if len(argv[1:]) == 0:
        print ("\nUsage for displaying on screen: pssm_n1.py -i pssm_col_file -o outputfile\n")
        print ("Usage: python pssm_n1.py -i pssm_col_file -o outputfile\n")
        print ("-i\tGive PSSM_COL_FILE input file name\n-o\tOutput file name\n ")
        sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
   except getopt.GetoptError:
      print ('pssm_n1.py -i <inputfile> -o <outputfile>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('pssm_n1.py -i <inputfile> -o <outputfile>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
   orig_stdout = sys.stdout
   n = open(outputfile,'w')
   sys.stdout = n
   
   df=pd.read_csv(inputfile, sep=',',header=None)
   df1 = df.iloc[:,0:21]
   def pssm(x):
       # that, if x is a string,
       if type(x) is str:
           # just returns it untouched
           return x
       # but, if not, return it multiplied by 100
       elif x:
           return (1/(1+(2.7182)**(-x)))
        # and leave everything else
       else:
           return
   df2 = df1.applymap(pssm)
   df2.to_csv(outputfile, encoding='utf-8', index=False, header=False)		 
   #print(bb)
  # print(*bb, sep='\n')
   #for p in bb: print (p)
   #print ('\n'.join(str(p) for p in bb))
   #sys.stdout = orig_stdout
   #n.close()

if __name__ == "__main__":
   #main(sys.argv[1:])
   main(sys.argv[1:])
