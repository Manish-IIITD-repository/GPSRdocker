#=================================================================
# program developed to  normalize pssm profile ( = 1/(1+e-x)
# Usage: pssm_comp.py -i pssm_col_file -o outputfile
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy as np
import pandas as pd

def main(argv):
   inputfile = ''
   outputfile = ''
   if len(argv[1:]) == 0:
        print ("\nUsage for displaying on screen: pssmcomp.py -i pssm_col_file -o outputfile\n")
        print ("Usage: python pssmcomp.py -i pssm_col_file -o outputfile\n")
        print ("-i\tGive PSSM_COL_FILE input file name\n-o\tOutput file name\n ")
        sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
   except getopt.GetoptError:
      print ('pssmcomp.py -i <inputfile> -o <outputfile>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('pssmcomp.py -i <inputfile> -o <outputfile>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
   orig_stdout = sys.stdout
   n = open(outputfile,'w')
   sys.stdout = n
   Matrix = [[0 for x in range(0,20)] for y in range(0,20)]
   aa = list("ACDEFGHIKLMNPQRSTVWY")
   df=pd.read_csv(inputfile, sep=',',header=None)
   df.set_index(0,inplace=True)
   j = 0
   df2 = []
   for i in aa:
      if i in df.index[:]:
         df1 = df.loc[i]
         df2 = (df1.sum(axis=0)/len(df))
         Matrix[j] =np.asarray(df2)
         j = j+1
      else:
         j = j+1
   np.savetxt(outputfile,Matrix,fmt='%.4f',delimiter=",",newline=',')
   #print(bb)
  # print(*bb, sep='\n')
   #for p in bb: print (p)
   #print ('\n'.join(str(p) for p in bb))
   #sys.stdout = orig_stdout
   #n.close()

if __name__ == "__main__":
   #main(sys.argv[1:])
   main(sys.argv[1:])
