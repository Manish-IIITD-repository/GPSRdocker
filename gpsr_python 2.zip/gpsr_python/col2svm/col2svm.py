
#=================================================================
# program developed  To generate SVM_light input formats
# Usage: :col2svm -i se1.out -o svm.out -s +1
#
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   outputfile = ''
   dk = ""
   if len(argv[1:])==0:
       print("\n Usage for displaying on screen: python col2svm.py -i se1.out -o svm.out -s +1")
       print("usage python col2svm.py -i se1.out -o svm.out -s +1\n")
       print("-i\t Give se1.out file name\n-o\t Output file name\n-s\t +1/-1")
       sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:s:",["ifile=","ofile=","sfile="])
      #print(opts)
   except getopt.GetoptError:
      print ('col2svm.py -i <sel.out> -o <svm.out> -s +1')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('col2svm.py -i <sel.out> -o <svm.out> -s +1')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-s","--sfile"):
         dk += arg + " "

   output = open(outputfile,'w')
   u = 0
   c = []
   b = []
   with open(inputfile,'r') as f:
       a = f.readlines()
       for each in a:
         temp = each.split(",")
         for ex in temp:
           if u == 1:
             c.append(ex.replace(" ","").replace("#","").replace("\n",""))
           elif u == 2:
             b.append(float("{0:.4f}".format(float(ex.replace(" ","").replace("\n","")))))
         u += 1
   

   di = 1
   for d in b:
    dk += str(di) + ":" + str(d) + " " 
    di += 1
   output.write(dk)
   output.close()
if __name__ == "__main__":
   main(sys.argv[1:])

