import sys, getopt
import numpy
import itertools

def main(argv):
   inputfile = ''
   outputfile = ''
   window = 1
   try:
       # opts is a list of returning key-value pairs, args is the options left after striped
       # the short options 'hi:o:', if an option requires an input, it should be followed by a ":"
       # the long options 'ifile=' is an option that requires an input, followed by a "="
      opts, args = getopt.getopt(argv,"i:o:w:",["ifile=","ofile=","window="])
   except getopt.GetoptError:
      print ('pssm_smooth.py -i <inputfile> -o <outputfile> -w <number>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('pssm_smooth.py -i <inputfile> -o <outputfile> -w <number>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-w", "--window"):
         window = int(sys.argv[6])
   
   with open(inputfile,'r') as f:
    g = list(f)
	
   orig_stdout = sys.stdout
   n = open(outputfile,'w')
   sys.stdout = n	
	
   no_insert_seq = (window-1)/2
   x1 = 'X, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0\n'
   i = 0
   j = 0
   while j < no_insert_seq:
    g.insert(0,x1)
    g.insert(len(g),x1)
    j += 1

   k = no_insert_seq
   m = 0
   i1 = 0
   j1 = no_insert_seq
   l = 0
   r = 1

   while i < len(g) :
    g[i] = g[i].replace('\n','')
    g[i] = g[i].replace(" ","")
    g[i] = g[i].split(",")
    i += 1		
 
   h = zip(*g)
   arr = []
   i1 = 0
   j1 = no_insert_seq
   while i1 < len(h)-1 :
    arr.append([])
    while j1 < len(h[0]) - no_insert_seq :
     if i1 > 0 :
      temp = h[i1][j1-no_insert_seq : j1 + no_insert_seq + 1]
      add =  sum(int(val) for val in temp)
      arr[i1].append(add/window)
     j1 += 1
    j1 = no_insert_seq
    i1 += 1
 
   arr.pop(0)
   z = h[0]
   xx = z[no_insert_seq : len(z)-no_insert_seq]
   arr.insert(0,xx)
   arr1 = map(list, zip(*arr))
   #ff = arr1.tolist()
   print(str(arr1).replace('[','').replace('], ','').replace("'",""))
 
main(sys.argv[1:]) 
