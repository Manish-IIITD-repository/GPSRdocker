import sys, getopt
#from Bio import SeqIO

infile=''
temp1=''
def main(argv):
  inputfile = ''
  outputfile = ''
  windowfile = ''
  extensionfile = ''
 
  #print(len(argv[1:]))
  #print(argv[1:])

  if len(argv[1:]) == 0:
#        print ('seq2motif.py -i <inputfile> -o <outputfile> -w <window> -x <extension>')
        print ("\nProgram to create motifs by sliding window. GENRATE MOTIFS WITH or WITHOUT 'X' AT THE N AND C TERMINAL OF THE SEQUENCE IF NEEDED.\n")
        print ("Usage:python seq2motif.py -i inputFile -w window size -x extension -o outputFile\n")
        print ('-i\tInputFile (SFASTA FORMAT)\n-w\tWindow size to create motifs\n-x\t[y|n] extension of X needed or not\n-o\tOutput Motif file\n')
        sys.exit()
#  print("in function")
  try:
#    print ('in try')
    opts, args = getopt.getopt(argv,"hi:o:w:x:",["ifile=","ofile=", "window", "extension"])
  
  except getopt.GetoptError:

    print ('seq2motif.py -i <inputfile> -o <outputfile> -w <window> -x <extension>')
    sys.exit(2)  
   
  for opt, arg in opts:
      if opt == '-h':
         print ('seq2motif.py -i <inputfile> -o <outputfile> -w <window> -x <extension>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
         infile=inputfile
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-w", "--window"):
          windowfile = arg
      elif opt in ("-x", "--extension"):
          extensionfile = arg   
#  print (inputfile)
#  print (outputfile)
#  print (windowfile)
#  print (extensionfile)	           

  with open(inputfile,'r') as f:
    g = list(f)
    #temp = f.readlines()

#  print (g)
 
  orig_stdout = sys.stdout
  n = open(outputfile,'w')  
  sys.stdout = n

  

  aa =('A','C','D','E','F','G','H','I','K','L','M','N','P','Q','R','S','T','V','W','Y')
#  print("Program to create motifs by sliding window\n")
#  print("A , C , D , E , F , G , H , I , K , L , M , N , P , Q , R , S , T , V , W , Y\n")

  k= (int(windowfile)-1)/2
  new_str = "X" * int(k)


  for i in g:
#        print(i)
#        print (new_str)
        a = i.split('##')
#        print(a)
        print (a[0])
        b = a[1]
        c = b.replace('\n','')

        if (extensionfile == 'y'):

        	c =new_str+c+new_str
        for j in range(0,len(c)):
            d = c[j:j+int(windowfile)]
            if len(d)==int(windowfile):
                print(d)


main(sys.argv[1:])