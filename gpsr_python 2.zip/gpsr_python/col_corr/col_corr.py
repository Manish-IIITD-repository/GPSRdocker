#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   #inputfile2 = ''
   outputfile = ''
   st_col = 1
   l_col = 1
   h = 0
   
   if len(argv[1:]) == 0:
#        print ('col_corr.py -i <inputfile1> -o <inputfile2> -a <st_col> -b <l_col>')
        print ("\nTo compute correlation co-efficient between two column\n")
        print ("Usage:python col_corr.py -i <inputfile> -o <outputfile> -a <st_col> -b <l_col>\n")
        print ('-i\tInputFile\n-o\tOutputFile\n-a\tNumber of starting column (eg 1)\n-b\tNumber of last column (eg 3)\n')
        sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:a:b:",["ifile1=","ofile=","st_col=","l_col="])
   except getopt.GetoptError:
      print ('col_corr.py -i <inputfile> -o <outputfile> -a <st_col> -b <l_col>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('col_corr.py -i <inputfile> -o <outputfile> -a <st_col> -b <l_col>')
         sys.exit()
      elif opt in ("-i", "--ifile1"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg	 
      elif opt in ("-a", "--st_col"):
          st_col = int(sys.argv[6]) 
      elif opt in ("-b", "--l_col"):
          l_col = int(sys.argv[8]) 	
   #print(st_col)
   #print(l_col)   
	  
   with open(inputfile,'r') as f:
    g = list(f)	 

   orig_stdout = sys.stdout
   n = open(outputfile,'w')	
   sys.stdout = n 
   
   i = 0 
   a = st_col - 1
   k = l_col - 1
   s = 2
   cal = 0
   j = 0
   j1 = 0
   num = 0
   den = 0
   den1 = 0
   den2 = 0
   i1 = 0
   corr = 0
   
   while i < len(g) :
    g[i] = g[i].replace("\n","")
    g[i] = g[i].replace("#","")
    g[i] = g[i].replace(" '","")
    g[i] = g[i].rstrip()
    i += 1
 
   g2 = g
   while h < len(g) :
    g2[h] = g[h].split(",")
    g2[h] = [y for y in g2[h] if y]
 #g2[h] = g2[h].pop
    h += 1
 
   #avg = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
   avg = []   
 
   while j < len(g[1]):
    while s < len(g) :
     if s > 1 :
      cal = cal + float(g2[s][j])
     s += 1 
    #avg[j] = cal/(len(g)-2)
    avg.append(cal/(len(g)-2))
    cal = 0 
    s = 2
    j += 1 
 

   while j1 < len(g) :
    if j1 > 1 :
     num = num + ((float(g2[j1][i1]) - avg[a])*(float(g2[j1][i1+k])-avg[a+k]))
     den1 = den1 + ((float(g2[j1][i1]) - avg[a])*(float(g2[j1][i1]) - avg[a]))
     den2 = den2 + ((float(g2[j1][i1+k])-avg[a+k])*(float(g2[j1][i1+k])-avg[a+k]))
    j1 += 1	
 
   import math
   den = math.sqrt(den1*den2)
   #if den != 0 :
   corr = num/den

   print(corr)  
   
if __name__ == "__main__":
   #main(sys.argv[1:])
 main(sys.argv[1:])        