#=================================================================
# program developed for computing amino acid composition of C-terminal (ct) residues of a proteins
# Usage: pro2aac_ct -i seq.sfa -o seq.out -n 5
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   outputfile = ''
   number = 1
   
   if len(argv[1:]) == 0:
        #print ("\nUsage for displaying on screen: python pro2aac_ct.py -i sfasta_file -n ct_residues(number)\n")
        print ("Usage: python pro2aac_ct.py -i sfasta_file -o output_file -n ct_residues(number)\n")
        print ("-i\tGive S-FASTA input file name\n-o\tOutput file name\n-n\tGive the number of residue for C terminal composition\n ")
        sys.exit()
		
   try:
       # opts is a list of returning key-value pairs, args is the options left after striped
       # the short options 'hi:o:', if an option requires an input, it should be followed by a ":"
       # the long options 'ifile=' is an option that requires an input, followed by a "="
      opts, args = getopt.getopt(argv,"i:o:n:",["ifile=","ofile=","number="])
   except getopt.GetoptError:
      print ('pro2aac_nt.py -i <inputfile> -o <outputfile> -n <number>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('pro2aac_nt.py -i <inputfile> -o <outputfile> -n <number>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-n", "--number"):
         number = int(sys.argv[6])
   #print("nt")
   #print(outputfile)
   #print(number)
    
   with open(inputfile,'r') as f:
    g = list(f)  
	
   #print(g)        
   orig_stdout = sys.stdout
   n1 = open(outputfile,'w')     
   sys.stdout = n1                
   
   aa = ['A','C','D','E','F','G','H','I','K','L','M','N','P','Q','R','S','T','V','W','Y']
   print("Amino acid composition of C-terminal residues of protein\n")
   print("#A , C , D , E , F , G , H , I , K , L , M , N , P , Q , R , S , T , V , W , Y\n")
   
   i = 0
   i1 = 0
   nt = 5
   count = 1
   count1 = 1
   k = 0
   n = 0 
   j = 0
   perc = 0
   r = 0
   s = 0 
   while i < len(g) :
    g[i] = g[i].replace("\n","")
    g[i] = g[i].split('##', 1)[-1]
    g[i] = list(reversed(g[i]))
    i = i + 1
 
   import numpy
   bb = numpy.zeros(shape=(i,20), dtype = object)

   while k < len(g) :
     g[k] = list(g[k]) 
     k = k + 1

   while i1 < k :
    while j < number :
     while n < number :
      if j != n :
       if g[i1][j] == g[i1][n] :
        count1 = count1 + 1
       else :
        count = count1 
      n += 1
     if(count1 > count) :
      perc = count1 * 100/number
     else :
      perc = count * 100/number
     #print(g[i1][j])
     #print(perc) 
     while r<20 :
      if (g[i1][j] == aa[r]) :
       bb[i1][r] = perc
      r += 1	
     n = 0
     r = 0
     count = 1
     count1 = 1
     j += 1
    #print(bb)
 
    #n = 0
    j = 0
    i1 += 1
    
   for r in bb:
    for c in r:
     print(c,end = ",")
    print() 
if __name__ == "__main__":
   #main(sys.argv[1:])
   main(sys.argv[1:])   
          
