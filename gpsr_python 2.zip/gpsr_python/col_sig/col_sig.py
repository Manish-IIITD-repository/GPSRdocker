#=================================================================
# significance of columns in two column files
# Usage: col_sig -i file1 -j file2 >out
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy
import math

def main(argv):
   inputfile1 = ''
   inputfile2 = ''
   outputfile = ''
   h = 0
   #print(argv[1:])
   if len(argv[1:]) == 0:
#        print ('col_sig.py -i <inputfile1> -j <inputfile2> > <outputfile>')
        print ("\nTo calculate average column of two files\n")
        print ("Usage:python col_sig.py -i <inputfile1> -j <inputfile2> > <outputfile>\n")
        print ('-i\tInputFile(first column file for avg)\n-j\tInputFile(second column file for avg)\n >\tOutput file\n')
        sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:j:o:",["ifile1=","ifile2=","ofile="])
   except getopt.GetoptError:
      print ('col_sig.py -i <inputfile1> -j <inputfile2> > <outputfile>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('col_sig.py -i <inputfile1> -j <inputfile2> > <outputfile>')
         sys.exit()
      elif opt in ("-i", "--ifile1"):
         inputfile1 = arg
      elif opt in ("-j", "--ifile2"):
         inputfile2 = arg	 
      elif opt in ("-o", "--ofile"):
         outputfile = arg
	 
   #print(opt)	 
		 
   with open(inputfile1,'r') as f1:
    g1 = list(f1)	
	
   with open(inputfile2,'r') as f2:
    g2 = list(f2)
    
   orig_stdout = sys.stdout
   n = open(outputfile,'w')	
   sys.stdout = n  
   
   i = 0
   j = 0
   h = 0
   k = 0
   sum_file1 = 0
   sum_file2 = 0
   m = 0
   n = 0
   p = 0
   temp1 = 0
   temp2 = 0
   z = 0
   am_acc = 0
   
   while i < len(g1) :
    g1[i] = g1[i].replace("\n","")
    g1[i] = g1[i].replace("#","")
    g1[i] = g1[i].replace(" '","")
    g1[i] = g1[i].rstrip()
    g2[i] = g2[i].replace("\n","")
    g2[i] = g2[i].replace("#","")
    g2[i] = g2[i].replace(" '","")
    g2[i] = g2[i].rstrip()
    i += 1 
    
   g3 = g1 
   g4 = g2
   while h < len(g1) :
    if h != 0 :
     g3[h] = g1[h].split(",")
     g3[h] = [y for y in g3[h] if y]
     g4[h] = g2[h].split(",")
     g4[h] = [y for y in g4[h] if y]
    h += 1

   g5 = g3[2:len(g3)+1]
   g6 = g4[2:len(g4)+1]  
   g1_sd = g3[2: len(g3) + 1]
   g2_sd = g4[2: len(g3) + 1]   
   g7 = []
   g8 = []
   
   while am_acc < len(g1[1]) :
    am_acc = am_acc + 1
   
   while j < len(g5[0]) :
    while k < len(g5) :
     sum_file1 = sum_file1 + float(g5[k][j])
     sum_file2 = sum_file2 + float(g6[k][j])
     k += 1
    g7.append(round(float(sum_file1/len(g5)),4))                               #avg1
    g8.append(round(float(sum_file2/len(g5)),4))                               #avg2 
    sum_file1 = 0
    sum_file2 = 0
    k = 0
    j += 1
    
   diff1 = []
   sig1 = []
   
   while m < len(g7) :
    sig1.append(float((g7[m] - g8[m]))*200) 
    diff1.append(float(sig1[m]/(g7[m] + g8[m])))                    #diff 
    m += 1

   g9 = []
   g10 = []
   while p < len(g1_sd[0]) :
    while n < len(g1_sd) :
     temp1 = temp1 + (float(g1_sd[n][p]) - g7[p])*(float(g1_sd[n][p]) - g7[p])
     temp2 = temp2 + (float(g2_sd[n][p]) - g8[p])*(float(g2_sd[n][p]) - g8[p])
     n += 1
    g9.append(math.sqrt(temp1/len(g1_sd)))                    #s.d.1
    g10.append(math.sqrt(temp2/len(g2_sd)))                   # s.d. 2
    temp1 = 0
    temp2 = 0
    n = 0
    p += 1   
    
   sig = []
   while z < len(g1_sd[0]) :
    sig.append(sig1[z]/(g9[z] + g10[z]))                     # sig
    z += 1     
    
   ps = []
   hh = 0
   jj = 0
   while hh < am_acc :
    ps.append(hh)
    hh += 1 
    
   print("# Parameters Measured: % Difference, Significance, Average1, Average2, Standard Deviation(SD1), SD2") 
   while jj < am_acc :   
    print ("Column{0}: {1} {2} {3} {4} {5} {6}".format(ps[jj], diff1[jj], sig[jj], g7[jj], g8[jj], g9[jj], g10[jj]))
    jj += 1
   
if __name__ == "__main__":
   #main(sys.argv[1:])
   main(sys.argv[1:])
       
    
    

   
   