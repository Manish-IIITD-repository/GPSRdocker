#############################################################################
##    'motif2bin' is free software: you can redistribute it and/or modify      #
##    it under the terms of the GNU General Public License as published by   #
##    the Free Software Foundation, either version 3 of the License, or      #
##    (at your option) any later version.                                    #
##############################################################################
##    This program is distributed in the hope that it will be useful,        #
##    but WITHOUT ANY WARRANTY; without even the implied warranty of         #
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          #
##    GNU General Public License for more details.                           #
##                                                                           #
##    You should have received a copy of the GNU General Public License      #
##    along with this program.  If not, see <http://www.gnu.org/licenses/>.  #
##############################################################################
## Orginally developed at Raghava's group <http://webs.iiitd.edu.in/raghava/>#

##############################################################################

#To make Binary input from the multifasta motif File
# Usage: motif2bin -i input_motifFile -o output_file -x y
#
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
    inputfile = ''
    outputfile = ''
    extensionfile = ''
    
    if len(argv[1:]) == 0:
#        print ('motif2bin.py -i <inputfile> -o <outputfile> -x <extension>')
        print ("\nProgram to create motifs by sliding window. GENRATE MOTIFS WITH or WITHOUT 'X' AT THE N AND C TERMINAL OF THE SEQUENCE IF NEEDED.\n")
        print ("Usage:python motif2bin.py -i inputFile -o outputFile -x extension\n")
        print ('-i\tInputFile (multifasta file)\n-o\tOutput file\n-x\t[y|n] extension of X needed or not\n')
        sys.exit()

    try:
      opts, args = getopt.getopt(argv,'hi:o:x:',['ifile=','ofile=','extension='])
      #print (opts)
      #print (args)
    except getopt.GetoptError:
      #print ("GOT AN EXCEPTION",sys.exc_info()[0])
      print ('motif2bin -i motif_1.out -o bin.out -x y')
      sys.exit(2)

    
    for opt, arg in opts:
      if opt == '-h':
         print ('motif2bin -i motif_1.out -o bin.out -x y')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-x", "--extension"):
          extensionfile = arg  	 
	  	 


    #print ("Output File", outputfile)
    orig_stdout = sys.stdout
    n = open(outputfile,'w')
    sys.stdout = n	

    #sys.stdout=output
    s = 0
    m = 0
    n = 0
    m1 = 0
    n1 = 0
    each = 0
    i = 0
    j = 0
    k = 0
    r = 0
    f1 = 0
    f2 = 0
    aa = []
    bb = []
    i1 = 0
    k1 = 0
    j1 = 0
    r1 = 0
      

    assign = ['A,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0','C,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0','D,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0','E,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0','F,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0','G,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0','H,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0','I,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0','K,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0','L,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0','M,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0','N,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0','P,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0','Q,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0','R,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0','S,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0','T,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0','V,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0','W,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0','Y,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1','X,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0']
    while s < len(assign):
     assign[s] = assign[s].split(",")
     s += 1 
    
    with open (inputfile,'r') as f:
     seq = f.readlines()[1:]

    while each < len(seq) :
     seq[each] = seq[each].replace('\n','')
     each += 1
     
    window = len(seq[0])
    wt = (window-1)//2
    
    p = len(assign[0])-1
    for m in range(len(seq)):
     aa.append([])
     for n in range(p*window) :
      aa[m].append(0) 
    
    t = 2*wt     
    for m1 in range(len(seq)-t):
     bb.append([])
     for n1 in range(p*window) :
      bb[m1].append(0)   

    if (extensionfile == 'y'):
     while i < len(seq) :
      k = 0
      while j < window :
       while r < len(assign) :
        if seq[i][j] == assign[r][0] :
         aa[i][j+k:j+19+k] = assign[r][1:21]
         f1 = 1
        #else :
         #if i - wt >= 0 and i < len(seq) - wt:
          #bb[i-wt][j+k:j+19+k] = assign[r][1:21]
          #f2 = 1 
        r += 1
       k += 19
       r = 0
       j += 1
      j = 0
      i += 1	
      
    i1 = wt
    if (extensionfile == 'n'):
     while i1 < len(seq)-wt :
      k1 = 0
      while j1 < window :
       while r1 < len(assign) :
        if seq[i1][j1] == assign[r1][0] :
         bb[i1-wt][j1+k1:j1+19+k1] = assign[r1][1:21]
         f2 = 1
        #else :
         #if i - wt >= 0 and i < len(seq) - wt:
          #bb[i-wt][j+k:j+19+k] = assign[r][1:21]
          #f2 = 1 
        r1 += 1
       k1 += 19
       r1 = 0
       j1 += 1
      j1 = 0
      i1 += 1  
    

    #print (a)
    if f1 == 1 :
     #print(', ,'.join([str(v) for v in aa]))
     for rt in aa:
      for ct in rt:
       print(ct,end = ",")
      print()
    if f2 ==1 :
     #print(', ,'.join([str(v) for v in bb]))
     for rt in bb:
      for ct in rt:
       print(ct,end = ",")
      print()
    

if __name__ == "__main__":
   #main(sys.argv[1:])
   main(sys.argv[1:])


