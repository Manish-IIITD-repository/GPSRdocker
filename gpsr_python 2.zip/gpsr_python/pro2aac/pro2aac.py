#=================================================================
# program developed for computing amino acid composition of proteins
# Usage: pro2aac -i seq.sfa -o seq.out
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   outputfile = ''
   if len(argv[1:])==0:
       #print("\n Usage for displaying on screen: python pro2dpc -i seq.sfa -o seq.out")
       print("usage python pro2aac.py -i seq.sfa -o seq.out\n")
       print("-i\t Input file(Input file name contains single fasta format) \n-o\t Output file ")
       sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
   except getopt.GetoptError:
      print ('pro2aac.py -i <inputfile> -o <outputfile>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('pro2aac.py -i <inputfile> -o <outputfile>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
		 
   with open(inputfile,'r') as f:
    g = list(f)	 
	
   orig_stdout = sys.stdout
   n = open(outputfile,'w')	
   sys.stdout = n

   aa = ['A','C','D','E','F','G','H','I','K','L','M','N','P','Q','R','S','T','V','W','Y']
   print("Amino acid composition in protein")
   print("#A , C , D , E , F , G , H , I , K , L , M , N , P , Q , R , S , T , V , W , Y")
   i = 0
   m = 0
   n = 0
   r = 0
   s = 0
   perc = 0
   count = 1
   count1 = 1

   while i < len(g) :
    g[i] = g[i].replace("\n","")
    g[i] = g[i].split('##', 1)[-1]
    i = i + 1
 
   bb = numpy.zeros(shape=(len(g),20), dtype = object)

   while m < len(g) :
    while n < len(g[0])-1 :
     while r < len(g[0])-1 :
      if n != r :
       if g[m][n] == g[m][r] :
        count1 = count1 + 1
       else :
        count = count1 
      r += 1
     if(count1 > count) :
      perc = count1 * 100/len(g[0])
     else :
      perc = count * 100/len(g[0]) 
     while s < 20 :
      if (g[m][n] == aa[s]) :
       bb[m][s] = round(perc,4)
      s += 1	
     r = 0
     s = 0
     count = 1
     count1 = 1
     n += 1
    n = 0
	#print(bb) 
    m += 1
	#print("\n")
      
   
   for r in bb:
    for c in r:
     print(c,end = ",")
    print()
   #for p in bb: print (p)
   #print ('\n'.join(str(p) for p in bb))
   #sys.stdout = orig_stdout
   #n.close()

if __name__ == "__main__":
   #main(sys.argv[1:])
   main(sys.argv[1:])