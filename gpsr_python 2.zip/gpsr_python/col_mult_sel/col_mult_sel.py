#=================================================================
# program developed  to multiply selective columns with a number
# Usage: col_mult_sel -i se1.out -o se1_mult -n 10 -a 1 -b 3
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   outputfile = ''
   dk = ""
   if len(argv[1:])==0:
          #print("\n Usage for displaying on screen: python col_mult_sel.py -i se1.out -o se1_mult -n 10 -a 1 -b 3")
          print("usage python col_mult_sel.py -i se1.out -o se1_mult -n 10 -a 1 -b 3\n")
          print("-i\t Input file name \n-o\t Output file name\n-n\t Number with which column is multiplying\n-a\t Number of starting column (eg 1)\n-b\t Number of last column (eg 3)")
          sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:n:a:b:c",["ifile=","ofile="])
      #print(opts)
   except getopt.GetoptError:
      print ('col_mult_sel -i se1.out -o se1_mult -n 10 -a 1 -b 3')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-n","--nfile"):
         n = float(arg)
      elif opt in ("-a","--nfile"):
         ia = int(arg)
      elif opt in ("-b","--nfile"):
         ib = int(arg)

   output = open(outputfile,'w')
   u = 0
   bb = []

   with open(inputfile,'r') as f:
       a = f.readlines()
       for each in a:
         temp = each.split(",")

         d = []

         i = 1
         for ex in temp:
           if u > 1:
            if i >= ia and i <= ib:
              d.append(float(ex.replace(" ","").replace("\n",""))*n)
            else:
              d.append(float(ex.replace(" ","").replace("\n","")))
               
            i += 1

         bb.append(d)
         u += 1

   
   for v in bb:
      if len(v) != 0:
         for vi in v:
            dk += str(vi) + ","
         dk += "\n"

   
   output.write(dk)
   output.close()



if __name__ == "__main__":
   main(sys.argv[1:])
