#=================================================================
# program developed for computing amino acid composition of proteins after removing N-, and C-terminal residues
# Usage: pro2aac_rest -i seq.sfa -o seq.out -n 5 -c 5
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   outputfile = ''
   number1 = 1
   number2 = 1
   
   if len(argv[1:]) == 0:
    print ("\nUsage for displaying on screen: python pro2aac_rest.py -i seq.sfa -o seq.out -n 5 –c 5\n")
    print ("Usage: python pro2aac_rest -i seq.sfa -o seq.out -n 5 –c 5\n")
    print("Length of all the sequences should be same")
    print ("-i\tGive S-FASTA input file name\n-o\t seq.out Output file name\n-n\t number of residue for N terminal\n-c\t number of residue for C terminal composition\n ")
    sys.exit()
		
   try:
       # opts is a list of returning key-value pairs, args is the options left after striped
       # the short options 'hi:o:', if an option requires an input, it should be followed by a ":"
       # the long options 'ifile=' is an option that requires an input, followed by a "="
      opts, args = getopt.getopt(argv,"i:o:n:c:",["ifile=","ofile=","number1=", "number2="])
   except getopt.GetoptError:
      print ('Error')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('pro2aac_rest.py -i <inputfile> -o <outputfile> -n <number1> -c <number2>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-n", "--number1"):
         number1 = int(sys.argv[6])
      elif opt in ("-c", "--number2"):
         number2 = int(sys.argv[8])		
   #print("nt")
   #print(outputfile)
   #print(number2)
    
   with open(inputfile,'r') as f:
    g = list(f)  
	
          
   orig_stdout = sys.stdout
   n1 = open(outputfile,'w')     
   sys.stdout = n1                
   
   aa = ['A','C','D','E','F','G','H','I','K','L','M','N','P','Q','R','S','T','V','W','Y']
   print("Amino acid composition of protein after removing N-, and C-terminal residues")
   print("#A , C , D , E , F , G , H , I , K , L , M , N , P , Q , R , S , T , V , W , Y")
   
   i = 0
   i1 = 0
   nt = 5
   count = 1
   count1 = 1
   k = 0
   n = 0 
   j = 0
   perc = 0
   r = 0
   s = 0 
   new_len = 0
   while i < len(g) :
    g[i] = g[i].replace("\n","")
    g[i] = g[i].split('##', 1)[-1]
    i = i + 1
	
   def remove_cruft(s):
    return s[number1:-(number2)]		
		
   g = [remove_cruft(s) for s in g]
   p = len(g[0]) 	
   #new_len = p - (number1+number2)
 
   import numpy
   bb = numpy.zeros(shape=(i,20), dtype = object)

   while k < len(g) :
     g[k] = list(g[k]) 
     k = k + 1

   while i1 < k :
    while j < p :
     while n < p :
      if j != n :
       if g[i1][j] == g[i1][n] :
        count1 = count1 + 1
       else :
        count = count1 
      n += 1
     if(count1 > count) :
      perc = count1 * 100/p
     else :
      perc = count * 100/p
     #print(g[i1][j])
     #print(perc) 
     while r<20 :
      if (g[i1][j] == aa[r]) :
       bb[i1][r] = round(perc,4)
      r += 1	
     n = 0
     r = 0
     count = 1
     count1 = 1
     j += 1
    #print(bb)
 
    #n = 0
    j = 0
    i1 += 1
    #print(aa)
   for r in bb:
    for c in r:
     print(c,end = ",")
    print()  
   #sys.stdout = orig_stdout
   #n1.close()
   
if __name__ == "__main__":
   #main(sys.argv[1:])
   main(sys.argv[1:])   
          
