#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   #inputfile2 = ''
   outputfile = ''
   st_col = 1
   l_col = 1
   h = 0
   
   if len(argv[1:]) == 0:
#        print ('col_ext.py -i <inputfile1> -o <inputfile2> -a <st_col> -b <l_col>')
        print ("\nTo extract selective columns from a file\n")
        print ("Usage:python col_ext.py -i <inputfile> -o <outputfile> -a <st_col> -b <l_col>\n")
        print ('-i\tInputFile\n-o\tOutputFile\n-a\tNumber of starting column (eg 1) to extracted\n-b\tNumber of last column (eg 3) extracted \n')
        sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:a:b:",["ifile1=","ofile=","st_col=","l_col="])
   except getopt.GetoptError:
      print ('col_ext.py -i <inputfile> -o <outputfile> -a <st_col> -b <l_col>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('col_ext.py -i <inputfile> -o <outputfile> -a <st_col> -b <l_col>')
         sys.exit()
      elif opt in ("-i", "--ifile1"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg	 
      elif opt in ("-a", "--st_col"):
          st_col = int(sys.argv[6]) 
      elif opt in ("-b", "--l_col"):
          l_col = int(sys.argv[8]) 	
   #print(st_col)
   #print(l_col)   
	  
   with open(inputfile,'r') as f:
    g = list(f)	 

   orig_stdout = sys.stdout
   n = open(outputfile,'w')	
   sys.stdout = n 
   i = 0 
   while i < len(g) :
    g[i] = g[i].replace("\n","")
    g[i] = g[i].replace("#","")
    g[i] = g[i].replace(" '","")
    g[i] = g[i].rstrip()
    i += 1
 
   #g11 = g[1].split(",")
   #g11 = [y for y in g11 if y]

   g2 = g[2].split(",")
   g2 = [x for x in g2 if x]
   
   s = st_col - 1 
   l = l_col  

   #g31 = g11[s + l:len(g11)]
   g3 = g2[s:l]

#print(g31)

   #print(g3)   
   for r in g3:
    print(r,end = ",")
    
   
if __name__ == "__main__":
   #main(sys.argv[1:])
 main(sys.argv[1:])        