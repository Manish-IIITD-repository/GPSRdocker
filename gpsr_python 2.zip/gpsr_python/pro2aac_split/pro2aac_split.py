#=================================================================
# program to Split Amino acid composition of protein
# Usage: pro2aac_split -i seq.sfa -o seq.out -n 3
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   outputfile = ''
   number = 1
   
   if len(argv[1:]) == 0:
        #print ("\nUsage for displaying on screen: python pro2aac_split sfasta_file n(number between 2 to 5)\n")
        print ("Usage: python pro2aac_split sfasta_file output_file n (number between 2 to 5)\n")
        print ("-i\tGive S-FASTA input file name\n-o\tOutput file name\n-n\tNumber of split part\n ")
        sys.exit()
		
   try:
       # opts is a list of returning key-value pairs, args is the options left after striped
       # the short options 'hi:o:', if an option requires an input, it should be followed by a ":"
       # the long options 'ifile=' is an option that requires an input, followed by a "="
      opts, args = getopt.getopt(argv,"i:o:n:",["ifile=","ofile=","number="])
   except getopt.GetoptError:
      print ('pro2aac_split.py -i <inputfile> -o <outputfile> -n <number>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('pro2aac_split.py -i <inputfile> -o <outputfile> -n <number>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-n", "--number"):
         number = int(sys.argv[6])
   #print(number)
   orig_stdout = sys.stdout
   n = open(outputfile,'w')
   sys.stdout = n

   with open(inputfile, 'r') as f:
    g = list(f)
	
   print("Split Amino acid composition of protein")
   print("A , C , D , E , F , G , H , I , K , L , M , N , P , Q , R , S , T , V , W , Y")
   i = 0
   i1 = 0
   nt = 5
   count = 1
   count1 = 1
   k = 1
   n = 0 
   m = 0
   j = 0
   perc = 0
   r = 0
   s = 0
   x = 0
   y = 1
   t = 1
   q = 0
   p = 0
   u = 0
   v = 1
   i1 = 0
   j1 = 1
   pp = 0
   sum = []
   aa=['A' , 'C' , 'D' , 'E' , 'F' , 'G' , 'H' , 'I' , 'K' , 'L' , 'M' , 'N' , 'P' , 'Q' , 'R' , 'S' , 'T' , 'V' , 'W' , 'Y']
   part_len = numpy.zeros(shape=(1,number+1),dtype=object)
   part_len1 = numpy.zeros(shape=(1,number+1),dtype=object)
   part_len2 = numpy.zeros(shape=(1,number+1),dtype=object)

   while i < len(g) :
    g[i] = g[i].replace("\n","")
    g[i] = g[i].split('##', 1)[-1]
    i = i + 1
 
   part_len[0][0] = 0 
   if len(g[0]) % number == 0:
    while y < number + 1 :
     part_len[0][y]= int(len(g[0])/number)
     y += 1
   else :
    while t < number+1 :
     if t != number - 1 :
      part_len[0][t] = int(len(g[0])/number)
     else :
      part_len[0][t] = int(len(g[0])/number)+(len(g[0])%number)
     t += 1
		
    
   while j1 < number + 1 :
    part_len1[0][j1] = part_len1[0][j1-1] + part_len[0][j1]
    part_len2[0][j1] = part_len1[0][j1] 	
    j1 += 1 
	 
     #else :		
      #part_len1[0][j1] = part_len[0][j1]  
      #part_len2[0][j1] = part_len[0][j1] 
   while pp < len(g) :
    g[pp] = g[pp] + '#'
    pp = pp + 1
#import textwrap
#from itertools import islice
   while m < len(g) :
    while u < number :
     while v < number+1 :
      if v - u == 1 :
       sum = sum +[g[m][part_len1[0][u]:part_len2[0][v]]] 
      v += 1    
     v = 1 
     u += 1
    u = 0    
    m += 1

    
   bb = numpy.zeros(shape=(i*number,20), dtype=object)
   g = sum
    
   while n < len(g) :
    if k < number+1 :
     while r < part_len[0][k] :
      while q < part_len[0][k] :
       if r != q :
        if g[n][r] == g[n][q] :
         count1 = count1+1
        else :
         count = count1
       q += 1
      if(count1 > count) :
       cal = count1
      else :
       cal = count
      while s < 20 :
       if (g[n][r] == aa[s]) :
        bb[n][s] = cal
       s += 1
      q = 0
      s = 0
      count = 1
      count1 = 1
      r += 1
     r = 0
     k += 1
    k = 1
    n += 1      
     
   for r in bb:
    for c in r:
     print(c,end = ",")
    print()   
 
if __name__ == "__main__":
   #main(sys.argv[1:])
   main(sys.argv[1:])    

 
 
 
