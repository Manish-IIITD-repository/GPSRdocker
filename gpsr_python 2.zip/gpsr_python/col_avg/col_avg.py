#=================================================================
# program developed to avg columns of two files
# Usage: col_avg -a pos1 -b pos2.out  -o out
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile1 = ''
   inputfile2 = ''
   outputfile = ''
   h = 0
   
   
   if len(argv[1:]) == 0:
#        print ('col_avg.py -a <inputfile1> -b <inputfile2> -o <outputfile>')
        print ("\nTo calculate average column of two files\n")
        print ("Usage:python col_avg.py -a <inputfile1> -b <inputfile2> -o <outputfile>\n")
        print ('-a\tInputFile(first column file for avg)\n-b\tInputFile(second column file for avg)\n-o\tOutput file\n')
        sys.exit()
   try:
      opts, args = getopt.getopt(argv,"ha:b:o:",["ifile1=","ifile2=","ofile="])
   except getopt.GetoptError:
      print ('col_avg.py -a <inputfile1> -b <inputfile2> -o <outputfile>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('col_avg.py -a <inputfile1> -b <inputfile2> -o <outputfile>')
         sys.exit()
      elif opt in ("-a", "--afile1"):
         inputfile1 = arg
      elif opt in ("-b", "--afile2"):
         inputfile2 = arg	 
      elif opt in ("-o", "--ofile"):
         outputfile = arg
		 
   with open(inputfile1,'r') as f1:
    g1 = list(f1)	
	
   with open(inputfile2,'r') as f2:
    g2 = list(f2)
    
   orig_stdout = sys.stdout
   n = open(outputfile,'w')	
   sys.stdout = n  
    
   i = 0 
   s = 0
   cal = 0
   j = 0
   j1 = 0
   num = 0
   den = 0
   den1 = 0
   den2 = 0
   i1 = 0
   corr = 0 
    
   while i < len(g1) :
    g1[i] = g1[i].replace("\n","")
    g1[i] = g1[i].replace("#","")
    g1[i] = g1[i].replace(" '","")
    g1[i] = g1[i].rstrip()
    g2[i] = g2[i].replace("\n","")
    g2[i] = g2[i].replace("#","")
    g2[i] = g2[i].replace(" '","")
    g2[i] = g2[i].rstrip()
    i += 1 
 
   g3 = g1 
   g4 = g2
   while h < len(g1) :
    if h != 0 :
     g3[h] = g1[h].split(",")
     g3[h] = [y for y in g3[h] if y]
     g4[h] = g2[h].split(",")
     g4[h] = [y for y in g4[h] if y]
    h += 1
 
   import numpy
   s = numpy.zeros(shape=(len(g1)-2,len(g1[1])), dtype=object) 
   #s = []
   #sum = 0
   while i1 < len(g1[1])-1 :
    while j1 < len(g1) :
     if j1 > 1 :
      s[j1-2][i1] = round((float(g3[j1][i1]) + float(g4[j1][i1]))/2,4)
      #s.append(round(float(g3[j1][i1]) + float(g4[j1][i1])),4)/2
     j1 += 1
    j1 = 2
    i1 += 1

   k1 = 0
   l1 = 0
   for r in s:
    for c in r:
     print(c,end = ";")
    print()    

if __name__ == "__main__":
   #main(sys.argv[1:])
 main(sys.argv[1:])     