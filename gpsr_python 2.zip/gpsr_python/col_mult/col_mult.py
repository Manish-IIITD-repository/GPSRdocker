#=================================================================
# To multiplying each column of input file with a number
# Usage: col_mult -i se1.out -o se1_mult -n 0.1
# 
#=================================================================
#!/usr/bin/python

import sys, getopt
import numpy

def main(argv):
   inputfile = ''
   outputfile = ''
   number1 = 1
   h = 0
   if len(argv[1:]) == 0:
#        print ('col_mult.py -i <inputfile1> -o <outputfile> -n <number>')
        print ("\nProgram To multiplying each column of input file with a number\n")
        print ("Usage:python col_mult.py -i <inputfile1> -o <outputfile> -n <number>\n")
        print ('-i\tInputFile\n-o\tOutput file\n-n\tNumber with which column is multiplying\n')
        sys.exit()
   try:
      opts, args = getopt.getopt(argv,"hi:o:n:",["ifile=","ofile=","number="])
   except getopt.GetoptError:
      print ('col_mult.py -i <inputfile> -o <outputfile> -n <number>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print ('col_mult.py -i <inputfile> -o <outputfile> -n <number>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
      elif opt in ("-n", "--number"):
         number1 = float(sys.argv[6])	 


   with open(inputfile, 'r') as f1:
    g1 = list(f1)
	
   orig_stdout = sys.stdout
   n = open(outputfile,'w')	
   sys.stdout = n	

   import numpy
   res = numpy.zeros(shape=(1,20))
 
   g1[2]=g1[2].split(',') 
   
   while h < len(g1[2]) : 
    res[0][h] = round(float(g1[2][h])* number1,4)
    h += 1
 
   #print(res)
   #print('\n'.join(str(v) for v in res))
   for r in res:
    for c in r:
     print(c,end = ",")
    print()
   
if __name__ == "__main__":
   #main(sys.argv[1:])
 main(sys.argv[1:])    
 
